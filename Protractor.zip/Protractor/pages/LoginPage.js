let LoginPage = function(){
	
//locators

let username_textbox = element(by.id('UserName'));
let password_textbox = element(by.id('Password'));
let login_button = element(by.className('w-login-form-btn'));
let click_CreateButton = element(by.className('a-srch-bar-create'));
let click_EngagementRequest = element(by.linkText('Engagement Request'));

// member functions
    this.get = function(url){
   		browser.get(url);
    }
   
	 this.login = function(username,password){
		username_textbox.sendKeys(username);
		password_textbox.sendKeys(password);
		login_button.click();
		click_CreateButton.click();
		click_EngagementRequest.click();
		}
	
	}



module.exports = new LoginPage();  // This statement allows access of above function outside this class