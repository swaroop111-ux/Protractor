let InherentRiskScreening=function(){
	
	let Triggered_Attribute_2 = element(by.xpath('//span[text()="Triggered Attributes"]//following::input[@class="ng-pristine ng-untouched ng-valid ng-not-empty"][1]'));
	let Triggered_Attribute_3 = element(by.xpath('//span[text()="Will / Does the service involve telecommunication or data center service?"]//following::input[@class="ng-pristine ng-untouched ng-valid ng-not-empty"][1]'));
	let Triggered_Attribute_4 = element(by.xpath('//span[text()="Will / Does the service involve software development?"]//following::input[1]'));
	let Triggered_Attribute_5 = element(by.xpath('//span[text()="Will / Does the service involve telecommunication or data center service?"]//following::input[5]'));
	let Triggered_Attribute_6 = element(by.xpath('//span[text()="Will / Does the service involve telecommunication or data center service?"]//following::input[7]'));
	let Triggered_Attribute_7 = element(by.xpath('//span[text()="Will / Does the service involve telecommunication or data center service?"]//following::input[9]'));
	let Triggered_Attribute_8 = element(by.xpath('//span[text()="Will / Does the service involve telecommunication or data center service?"]//following::input[11]'));
	let Triggered_Attribute_9= element(by.xpath('//span[text()="Will / Does the service involve telecommunication or data center service?"]//following::input[13]'));
	let Triggered_Attribute_10= element(by.xpath('//span[text()="Will / Does the service involve telecommunication or data center service?"]//following::input[15]'));
	let Triggered_Attribute_11= element(by.xpath('//span[text()="Will / Does the service involve telecommunication or data center service?"]//following::input[17]'));
	let Triggered_Attribute_12 = element.all(by.xpath('//span[@class="sap-icon--slim-arrow-down"]')).first();
	let Triggered_12_dropdown =  element(by.xpath('//span[text()="<1mil EUR"]'));
	let Triggered_Attribute_13 = element.all(by.xpath('//span[@class="sap-icon--slim-arrow-down"]')).get(1);
	let Triggered_13_dropdown = element(by.xpath('//span[text()="Low or Insignificant"]'));
	let NextOnTop_button = element.all(by.xpath('//span[text()="Next"]')).first();
	
	this.InherentRiskScreening1=function(){
		
	browser.sleep(20000);	
	Triggered_Attribute_2.click();
	browser.sleep(1000);
	Triggered_Attribute_3.click();
	browser.sleep(1000);
	Triggered_Attribute_4.click();
	browser.sleep(1000);
	Triggered_Attribute_5.click();
	browser.sleep(1000);
	Triggered_Attribute_6.click();
	browser.sleep(1000);
	Triggered_Attribute_7.click();
	browser.executeScript("arguments[0].click()",Triggered_Attribute_7);
	browser.sleep(1000);
	Triggered_Attribute_8.click();
	browser.executeScript("arguments[0].click()",Triggered_Attribute_8);
	browser.sleep(1000);
	Triggered_Attribute_9.click();
	browser.executeScript("arguments[0].click()",Triggered_Attribute_9);
	browser.sleep(1000);
	Triggered_Attribute_10.click();
	browser.executeScript("arguments[0].click()",Triggered_Attribute_10);
	browser.sleep(1000);
	Triggered_Attribute_11.click();
	browser.executeScript("arguments[0].click()",Triggered_Attribute_11);
	Triggered_Attribute_12.click();
	browser.executeScript("arguments[0].click()",Triggered_12_dropdown);
	Triggered_Attribute_13.click();
	browser.executeScript("arguments[0].click()",Triggered_13_dropdown);
	browser.sleep(20000);
	NextOnTop_button.click();
	browser.sleep(20000);
	
	
	}	}
module.exports = new InherentRiskScreening();  // This statement allows access of above function outside this class