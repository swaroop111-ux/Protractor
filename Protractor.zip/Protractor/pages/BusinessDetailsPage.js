let BusinessDetailsPage = function(){
	
//locators
let title_textbox = element(by.xpath('//span[text()="Title"]//following::input[1]'));
let commodity_textbox = element(by.xpath('//span[text()="Commodity"]/following::input[1]'));
let FRDM_Industry = element(by.xpath('//span[text()="Attachment"]//preceding::input[2]'));
let department_textbox = element(by.xpath('//span[text()="Department"]/following::input[1]'));
//let Outsourcing_Engagement = element(by.xpath('//span[text()="Contract Go-Live date or Milestone Date"]//preceding::input[@class="ng-pristine ng-untouched ng-valid ng-not-empty"][1]'));
//let cancel_button = element(by.id('cancel_engagement_request'));
let Next_button = element(by.xpath('//span[text()="US Dollar"]//following::button[@class="fd-button--emphasized pull-right"]')); // OR use xpath '//span[text()="Next"]'
// member functions

this.businessDetails = function(title, commodity, department){
	
	title_textbox.sendKeys(title);
	commodity_textbox.sendKeys(commodity);
	department_textbox.sendKeys(department);
	//Outsourcing_Engagement.click();
	FRDM_Industry.click();
	/*JavacriptExecutor jvx=(JavascriptExecutor);
	jvx.executeScript("arguments[0].click();",FRDM_Industry)*/
	browser.executeScript("arguments[0].click()",FRDM_Industry);
	//browser.sleep(20000);
	Next_button.click();
	browser.executeScript("arguments[0].click()",Next_button);
}   

/*this.cancelBusinessDetails = function(){
	cancel_button.click();
}  */
	
}

module.exports = new BusinessDetailsPage();  // This statement allows access of above function outside this class