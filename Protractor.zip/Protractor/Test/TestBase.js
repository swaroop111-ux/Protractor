let loginPage = require('../pages/LoginPage');


beforeAll(function() {
    browser.waitForAngularEnabled(false);
});

it('Login test',function(){

	loginPage.get('https://s1.ariba.com/Sourcing/Main/aw?awh=r&awssk=NqiCZXZk&realm=buymore-T&dard=1');
	browser.sleep(2000);
	
	loginPage.login('Swaroop001','Supplierrisk@12'); // update credentials for login
		
	console.log('Login successful');
	browser.sleep(20000);
});

let BusinessDetailsPage1 =require('../pages/BusinessDetailsPage')
it('Business test',function(){
	browser.sleep(2000);
	browser.ignoreSynchronization = false;
	browser.waitForAngularEnabled(true);
	let iFrame1 = browser.driver.findElement(By.id('RiskFrame'));
	browser.switchTo().frame(iFrame1);
	BusinessDetailsPage1.businessDetails('test_P001','Data base reporting software','Finance');
	console.log('Data Entered')
	browser.sleep(20000);
});

let Inherent_Questions=require('../pages/InherentRiskScreening')
it('Inherent test',function(){
	/*browser.sleep(20000);
	browser.ignoreSynchronization = false;
	 browser.waitForAngularEnabled(true);
	 let iFrame1 = browser.driver.findElement(By.id('RiskFrame'));
	 browser.switchTo().frame(iFrame1);*/
	Inherent_Questions.InherentRiskScreening1();
	browser.sleep(20000);
	console.log('Data Entered')
});

let SupplierDetails=require('../pages/Select_Supplier')
it('Supplier test',function(){
	/*browser.sleep(20000);
	browser.ignoreSynchronization = false;
	 browser.waitForAngularEnabled(true);
	 let iFrame1 = browser.driver.findElement(By.id('RiskFrame'));
	 browser.switchTo().frame(iFrame1);*/
	SupplierDetails.Supplier1();
	browser.sleep(20000);
	console.log('Data Entered')
});

let ReviewDetails=require('../pages/ReviewRequest')
it('Review test',function(){
	/*browser.sleep(20000);
	browser.ignoreSynchronization = false;
	 browser.waitForAngularEnabled(true);
	 let iFrame1 = browser.driver.findElement(By.id('RiskFrame'));
	 browser.switchTo().frame(iFrame1);*/
	browser.sleep(20000);
	ReviewDetails.ReviewRequest1();
	browser.sleep(20000);
	console.log('Data Verified')
});










	 




	
	
	



		









/*

// This spec is created for understanding the syntax of jasmine
let Buymore_Home = require('../pages/Buymore_Home'); // This is like import
describe('Creating new Engagement suite',function(){

/* Without POM

it('Addition test',function(){

// Enter URL
browser.get('http://juliemr.github.io/protractor-demo/');
expect(browser.getTitle()).toEqual('Super Calculator');
   
// locate elements   
       let numOne = element(by.model('first')); 
       let addButton = element(by.css('[value="ADDITION"]'));
       let numTwo = element(by.model('second'));
       let goButton = element(by.css('[ng-click="doAddition()"]'));
       let finalResult = element(by.cssContainingText('.ng-binding','60')); 
   
   // perform actual steps
       numOne.sendKeys(20);
       addButton.click();
       numTwo.sendKeys(40);
       
       goButton.click();
       
       browser.sleep(2000);
       expect(finalResult.getText()).toEqual('60');  

       console.log("Output of addition = ");
       console.log(finalResult.getText());
});

*/


/*
// Using POM
it('New Engagement test',function(){
	
	console.log("Inside NEW Engagement function");

// Enter URL
	Buymore_Home.get('https://s1.ariba.com/Sourcing/Main/aw?awh=r&awssk=NqiCZXZk&realm=buymore-T&dard=1');
	
	browser.sleep(2000);
	Buymore_Home.login('Priya001','Supplier@333');
   console.log("Before create Engagement screen");
// perform actual steps
       Buymore_Home.CreateEngagementRequest();
       
       browser.sleep(2000);
       

       console.log("On Engagement screen");
      // console.log(finalResult.getText());
});*/

