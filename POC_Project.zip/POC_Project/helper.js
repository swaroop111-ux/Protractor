var Helper = function(){
	this.waitForElement=function(element){
		browser.wait(() =>(element.isPresent()),60000);
	}
	this.waitForElementDisplayed=function(element){
		browser.wait(() =>(element.isDisplayed()),60000);
	}
	this.sleep = function(){
		browser.sleep(50000);
	}
	
	
	
}