// spec.js

var XLSX=require('xlsx');
var workbook=XLSX.readFile('C:\\Users\\Komal Purohit\\eclipse-workspace\\POC_Project\\InputNumbers.xlsx');

var first_sheet_name = workbook.SheetNames[0];
var address_of_cell1 = 'B2';
var address_of_cell2 = 'C2';
 
/* Below code is to get worksheet */
var worksheet = workbook.Sheets[first_sheet_name];
 
/* Below code is to find desired cell */
var desired_cell1 = worksheet[address_of_cell1];
var desired_cell2 = worksheet[address_of_cell2];

 
/* Below code is to get the value from cell */
var desired_value1 = desired_cell1.v;
var desired_value2 = desired_cell2.v;


describe('Protractor Demo App', function() {
  it('should have a title', function() {
    browser.get('http://juliemr.github.io/protractor-demo/');

    expect(browser.getTitle()).toEqual('Super Calculator');
    
   
        var numOne = element(by.model('first'));
        var addButton = element(by.css('[value="ADDITION"]'));
        var numTwo = element(by.model('second'));
        var goButton = element(by.id('gobutton'));
        var finalResult = element(by.binding('latest')); 
               
        numOne.sendKeys(desired_value1);
     //   addButton.click();
        numTwo.sendKeys(desired_value2);
        
        goButton.click();
        expect(finalResult.getText()).toEqual('55');         
       
  
  })
});