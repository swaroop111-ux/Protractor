describe('Enter GURU99 Name', function() {
 it('should add a Name as GURU99', function() {
 browser.get('https://yahoo.com');
 /*element(by.model('formData.name')).sendKeys('GURU99');
 element(by.model('formData.email')).sendKeys('xyz@gmail.com');
 browser.sleep(5000);*/


 
 
 /* var guru= element(by.xpath('html/body/div[2]/div[1]/div[2]/div[2]/div/h1'));
expect(guru.getText()).toEqual('Hello GURU99!');*/
 });
});