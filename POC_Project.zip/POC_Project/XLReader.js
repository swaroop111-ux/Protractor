var XLSX = require('xlsx');

class XLReader{
	
	read_from_excel(sheet1,filepath){
		
		var workbook = XLSX.readfile('./ReadData.xlsx');
		var worksheet =workbook.Sheets['Sheet1'];
		
		return XLSX.utils.sheet_to_jason(workbook);
		
		
		
		
		
	}
	
}